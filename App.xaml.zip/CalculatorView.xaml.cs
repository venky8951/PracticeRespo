﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MvvmUtilityLib;

namespace CalculatorApp
{
    /// <summary>
    /// Interaction logic for CalculatorView.xaml
    /// </summary>
    public partial class CalculatorView : Window
    {
        CalculatorModuleLib.CalculatorViewModel viewModelRef =new CalculatorModuleLib.CalculatorViewModel();
        public CalculatorView()
        {
            InitializeComponent();
            //this.DataContext = viewModelRef;
            //this.addButton.Command = viewModelRef.AddCommand;//hook the command to command property of view...
            //this.subButton.Command = viewModelRef.SubCommand;
            //this.mulButton.Command = viewModelRef.MulCommand;
            //this.divButton.Command = viewModelRef.DivCommand;
            #region Data Binding for Operand1 textbox
            //Binding
            //Binding _connector_operand1 = new Binding();
            ////Source Object
            //_connector_operand1.Source = viewModelRef;
            ////Source Property
            //_connector_operand1.Path = new PropertyPath("Operand1");
            ////mode
            //_connector_operand1.Mode = BindingMode.OneWayToSource;
            ////set target Property
            //this.Operand1.SetBinding(TextBox.TextProperty, _connector_operand1);
            //#endregion

            //#region Data Binding for operand 2 textbox
            //Binding _connector_operand2 = new Binding();
            //_connector_operand2.Source = viewModelRef;
            //_connector_operand2.Path = new PropertyPath("Operand2");
            //_connector_operand2.Mode = BindingMode.OneWayToSource;
            //this.Operand2.SetBinding(TextBox.TextProperty, _connector_operand2);
            //#endregion
            //#region Result data Binding
            //Binding _connector_result = new Binding();
            //_connector_result.Source = viewModelRef;
            //_connector_result.Path = new PropertyPath("Result");
            //_connector_result.Mode = BindingMode.OneWay;
            //this.Result.SetBinding(TextBox.TextProperty, _connector_result);
            #endregion
        }
    }
}
